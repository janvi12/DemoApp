//
//  CommentModel.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import Foundation

class ModelComment{
    
    let date: String
    let comment: String
    let owner: NSDictionary
    
    init(dict: NSDictionary) {
        date = dict.getStringValue(key: "publishDate")
        owner = dict.value(forKey: "owner") as! NSDictionary
        comment = dict.getStringValue(key: "message")        
    }
}
