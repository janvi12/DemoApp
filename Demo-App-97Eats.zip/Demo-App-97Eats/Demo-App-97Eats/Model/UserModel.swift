//
//  UserModel.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import Foundation

class ModelUser{
    
    let id: String
    let title: String
    let firstname: String
    let lastname: String
    let image: String
    
    init(dict: NSDictionary) {
        id = dict.getStringValue(key: "id")
        title = dict.getStringValue(key: "title")
        firstname = dict.getStringValue(key: "firstName")
        lastname = dict.getStringValue(key: "lastName")
        image = dict.getStringValue(key: "picture")
    }
}
