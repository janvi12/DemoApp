//
//  PostModel.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import Foundation

class ModelPost{
    
    let id: String
    let owner: NSDictionary
    let date: String
    let text: String
    let like: String
    let tag: NSArray
    let image: String
    
    init(dict: NSDictionary) {
        id = dict.getStringValue(key: "id")
        owner = dict.value(forKey: "owner") as! NSDictionary
        date = dict.getStringValue(key: "publishDate")
        text = dict.getStringValue(key: "text")
        like = dict.getStringValue(key: "likes")
        tag = dict.value(forKey: "tags") as! NSArray
        image = dict.getStringValue(key: "image")
    }
}
