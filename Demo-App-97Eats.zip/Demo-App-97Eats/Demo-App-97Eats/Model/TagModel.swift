//
//  TagModel.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import Foundation

class ModelTags{

    init(aryGetData: NSArray) {
        
    }
}


