//
//  ViewController.swift
//  Gaanap
//
//  Created by SBC on 15/03/18.
//  Copyright © 2018 Etpl. All rights reserved.
//

import Foundation
import UIKit

let appDelegate = UIApplication.shared.delegate as! AppDelegate

let MainStoryboard = UIStoryboard(name: "Main", bundle: nil)

let baseUrl = "https://dummyapi.io/data/v1/"
let getUserUrl = "user"
let getPostUrl = "post"
let getCommentUrl = "post/60d21af267d0d8992e610b8d/comment"
let getTagListUrl = "tag"
