//
//  TagsVC.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import UIKit
import CRNotifications
import SKActivityIndicatorView

class TagsVC: UIViewController, UITableViewDataSource {

    // MARK: Properties
    @IBOutlet weak var tblTags: UITableView!
    var aryData = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setTagsVC()
    }
    
    // MARK: Functions
    func setTagsVC()
    {
        tblTags.rowHeight = 50
        
        if(isConnectedToNetwork() == true)
        {
            SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
            SKActivityIndicator.show("loaderMessage".localized, userInteractionStatus: false)
            
            let dispatchTime: DispatchTime = DispatchTime.now() + Double(Int64(0.1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                self.callTagsApi()
            })
        }
        else
        {
            CRNotifications.showNotification(type:CRNotifications.info, title: "noInternet".localized, message: "noInternetMessage".localized, dismissDelay: 3)
        }
    }
    
    // Call Tags List api
    func callTagsApi()
    {
        let parameters: [String: String] = ["limit":"10"]
        
        callGetHeaderApi(fileName: getTagListUrl, parameters: parameters) { [self] responseObject, errorResponse in
            if(errorResponse == nil)
            {
                if let json = responseObject as? NSDictionary
                {
                    if let aryGetData = json.value(forKey: "data") as? NSArray
                    {
                        if aryGetData.count != 0
                        {
                            self.aryData = aryGetData
                            tblTags.reloadData()
                        }
                    }
                }
                else
                {
                    CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
                }
            }
            else
            {
                CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
            }
            SKActivityIndicator.dismiss()
        }
    }
    
    // MARK: UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TagsCell") as! TagsCell
        cell.selectionStyle = .none
                
        cell.lblTagName.text = aryData[indexPath.row] as? String
        
        return cell
    }
    
    // MARK: IBAction
    @IBAction func btnBack(_ sender: AnyObject)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
