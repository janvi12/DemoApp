//
//  PostsVC.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import UIKit
import CRNotifications
import SKActivityIndicatorView
import SDWebImage

class PostsVC: UIViewController, UITableViewDataSource {

    // MARK: Properties
    @IBOutlet weak var tblPosts: UITableView!
    var aryData = [ModelPost]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setPostsVC()
    }
    
    // MARK: Functions
    func setPostsVC()
    {
        tblPosts.rowHeight = 250
        
        if(isConnectedToNetwork() == true)
        {
            SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
            SKActivityIndicator.show("loaderMessage".localized, userInteractionStatus: false)
            
            let dispatchTime: DispatchTime = DispatchTime.now() + Double(Int64(0.1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                self.callPostApi()
            })
        }
        else
        {
            CRNotifications.showNotification(type:CRNotifications.info, title: "noInternet".localized, message: "noInternetMessage".localized, dismissDelay: 3)
        }
    }
    
    // Call Posts data api
    func callPostApi()
    {
        let parameters: [String: String] = ["limit":"10"]
        
        callGetHeaderApi(fileName: getPostUrl, parameters: parameters) { [self] responseObject, errorResponse in
            if(errorResponse == nil)
            {
                if let json = responseObject as? NSDictionary
                {
                    print(json)
                    
                    if let aryGetData = json.value(forKey: "data") as? NSArray
                    {
                        if aryGetData.count != 0
                        {
                            for result in aryGetData{
                                let obj = ModelPost(dict: result as! NSDictionary)
                                self.aryData.append(obj)
                            }
                            tblPosts.reloadData()
                        }
                    }
                }
                else
                {
                    CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
                }
            }
            else
            {
                CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
            }
            SKActivityIndicator.dismiss()
        }
    }
    
    // MARK: UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostsCell") as! PostsCell
        cell.selectionStyle = .none
        
        let dicData = aryData[indexPath.row].owner
        
        cell.lblUserNo.text = aryData[indexPath.row].id
        cell.lblUserName.text = (dicData.value(forKey: "title") as! String) + " " + (dicData.value(forKey: "firstName") as! String) + " " + (dicData.value(forKey: "lastName") as! String)
        
        cell.lblDate.text = aryData[indexPath.row].date
        cell.lblText.text = aryData[indexPath.row].text
        cell.lblLike.text = aryData[indexPath.row].like
        let aryTag = aryData[indexPath.row].tag
        cell.lblTag1.text = aryTag[0] as? String
        cell.lblTag2.text = aryTag[1] as? String
        cell.lblTag3.text = aryTag[2] as? String
        
        if let strProfilePic = dicData.value(forKey: "picture") as? String
        {
            cell.imgUser.sd_setImage(with: URL.init(string: strProfilePic), placeholderImage: UIImage.init(named: ""), options: .refreshCached, progress: nil, completed: nil)
        }
        
        if let strProfilePic = aryData[indexPath.row].image as? String
        {
            cell.imgPost.sd_setImage(with: URL.init(string: strProfilePic), placeholderImage: UIImage.init(named: ""), options: .refreshCached, progress: nil, completed: nil)
        }
        
        return cell
    }
    
    // MARK: IBAction
    @IBAction func btnBack(_ sender: AnyObject)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
