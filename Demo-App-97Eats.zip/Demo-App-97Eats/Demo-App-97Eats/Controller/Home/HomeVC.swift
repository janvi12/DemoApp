//
//  HomeVC.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // MARK: IBAction
    @IBAction func btnUsers(_ sender: AnyObject)
    {
        let usersVC = MainStoryboard.instantiateViewController(withIdentifier: "UsersVC") as! UsersVC
        self.navigationController?.pushViewController(usersVC, animated: true)
    }
    
    @IBAction func btnPosts(_ sender: AnyObject)
    {
        let postsVC = MainStoryboard.instantiateViewController(withIdentifier: "PostsVC") as! PostsVC
        self.navigationController?.pushViewController(postsVC, animated: true)
    }
    
    @IBAction func btnComments(_ sender: AnyObject)
    {
        let commentsVC = MainStoryboard.instantiateViewController(withIdentifier: "CommentsVC") as! CommentsVC
        self.navigationController?.pushViewController(commentsVC, animated: true)
    }
    
    @IBAction func btnTags(_ sender: AnyObject)
    {
        let tagsVC = MainStoryboard.instantiateViewController(withIdentifier: "TagsVC") as! TagsVC
        self.navigationController?.pushViewController(tagsVC, animated: true)
    }
}
