//
//  UserDetailVC.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import UIKit
import CRNotifications
import SKActivityIndicatorView

class UserDetailVC: UIViewController {

    // MARK: Properties
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDOB: UILabel!
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var lblStreet: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblCountry: UILabel!
    @IBOutlet weak var lblTimeZone: UILabel!
    var strId = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setUserDetailVC()
    }
    
    // MARK: Functions
    func setUserDetailVC()
    {
        if(isConnectedToNetwork() == true)
        {
            SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
            SKActivityIndicator.show("loaderMessage".localized, userInteractionStatus: false)
            
            let dispatchTime: DispatchTime = DispatchTime.now() + Double(Int64(0.1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                self.callUsersDetailApi()
            })
        }
        else
        {
            CRNotifications.showNotification(type:CRNotifications.info, title: "noInternet".localized, message: "noInternetMessage".localized, dismissDelay: 3)
        }
    }
    
    // Call Users detail data api
    func callUsersDetailApi()
    {
        let parameters: [String: String] = ["":""]
        
        callGetHeaderApi(fileName: getUserUrl + "/" + strId, parameters: parameters) { [self] responseObject, errorResponse in
            if(errorResponse == nil)
            {
                if let json = responseObject as? NSDictionary
                {
                    print(json)
                    
                    lblEmail.text = "Email: " + (json.value(forKey: "email") as? String ?? "")
                    lblPhone.text = "Phone: " + (json.value(forKey: "phone") as? String ?? "")
                    lblGender.text = "Gender: " + (json.value(forKey: "gender") as? String ?? "")
                    lblDOB.text = "Date of birth: " + (json.value(forKey: "dateOfBirth") as? String ?? "")
                    lblDate.text = "Register date: " + (json.value(forKey: "registerDate") as? String ?? "")
                    lblState.text = "State: " + (json.value(forKeyPath: "location.state") as? String ?? "")
                    lblStreet.text = "Street: " + (json.value(forKeyPath: "location.street") as? String ?? "")
                    lblCity.text = "City: " + (json.value(forKeyPath: "location.city") as? String ?? "")
                    lblCountry.text = "Country: " + (json.value(forKeyPath: "location.country") as? String ?? "")
                    lblTimeZone.text = "Timezone: " + (json.value(forKeyPath: "location.timezone") as? String ?? "")
                }
                else
                {
                    CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
                }
            }
            else
            {
                CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
            }
            SKActivityIndicator.dismiss()
        }
    }
    
    // MARK: IBAction
    @IBAction func btnBack(_ sender: AnyObject)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
