//
//  UsersVC.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import UIKit
import CRNotifications
import SKActivityIndicatorView
import SDWebImage

class UsersVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // MARK: Properties
    @IBOutlet weak var tblUsers: UITableView!
    var aryData = [ModelUser]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setUsersVC()
    }
    
    // MARK: Functions
    func setUsersVC()
    {
        tblUsers.rowHeight = 100
        
        if(isConnectedToNetwork() == true)
        {
            SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
            SKActivityIndicator.show("loaderMessage".localized, userInteractionStatus: false)
            
            let dispatchTime: DispatchTime = DispatchTime.now() + Double(Int64(0.1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                self.callUsersApi()
            })
        }
        else
        {
            CRNotifications.showNotification(type:CRNotifications.info, title: "noInternet".localized, message: "noInternetMessage".localized, dismissDelay: 3)
        }
    }
    
    // Call Users data api
    func callUsersApi()
    {
        let parameters: [String: String] = ["limit":"10"]
        
        callGetHeaderApi(fileName: getUserUrl, parameters: parameters) { [self] responseObject, errorResponse in
            if(errorResponse == nil)
            {
                if let json = responseObject as? NSDictionary
                {
                    print(json)
                    
                    if let aryGetData = json.value(forKey: "data") as? NSArray
                    {
                        if aryGetData.count != 0
                        {
                            for result in aryGetData{
                                let obj = ModelUser(dict: result as! NSDictionary)
                                self.aryData.append(obj)
                            }
                            tblUsers.reloadData()
                        }
                    }
                }
                else
                {
                    CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
                }
            }
            else
            {
                CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
            }
            SKActivityIndicator.dismiss()
        }
    }
    
    // MARK: IBAction
    @IBAction func btnBack(_ sender: AnyObject)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    // MARK: UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserListCell") as! UserListCell
        cell.selectionStyle = .none
        
        cell.lblUserNo.text = aryData[indexPath.row].id
        cell.lblUserName.text = aryData[indexPath.row].title + " " + aryData[indexPath.row].firstname + " " + aryData[indexPath.row].lastname
        
        if let strProfilePic = aryData[indexPath.row].image as? String
        {
            cell.imgUser.sd_setImage(with: URL.init(string: strProfilePic), placeholderImage: UIImage.init(named: ""), options: .refreshCached, progress: nil, completed: nil)
        }
        
        return cell
    }
    
    // MARK: UITableViewDelegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userDetailVC = MainStoryboard.instantiateViewController(withIdentifier: "UserDetailVC") as! UserDetailVC
        userDetailVC.strId = aryData[indexPath.row].id
        self.navigationController?.pushViewController(userDetailVC, animated: true)
    }
}
