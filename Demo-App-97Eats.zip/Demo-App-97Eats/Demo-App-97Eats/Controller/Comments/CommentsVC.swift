//
//  CommentsVC.swift
//  Demo-App-97Eats
//
//  Created by Jahanvi Trivedi on 13/01/22.
//

import UIKit
import CRNotifications
import SKActivityIndicatorView
import SDWebImage

class CommentsVC: UIViewController, UITableViewDataSource {

    // MARK: Properties
    @IBOutlet weak var tblComments: UITableView!
    var aryData = [ModelComment]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setCommentsVC()
    }
    
    // MARK: Functions
    func setCommentsVC()
    {
        tblComments.rowHeight = 120
        
        if(isConnectedToNetwork() == true)
        {
            SKActivityIndicator.spinnerStyle(.spinningFadeCircle)
            SKActivityIndicator.show("loaderMessage".localized, userInteractionStatus: false)
            
            let dispatchTime: DispatchTime = DispatchTime.now() + Double(Int64(0.1 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: dispatchTime, execute: {
                self.callCommentApi()
            })
        }
        else
        {
            CRNotifications.showNotification(type:CRNotifications.info, title: "noInternet".localized, message: "noInternetMessage".localized, dismissDelay: 3)
        }
    }
    
    // Call Users comments api
    func callCommentApi()
    {
        let parameters: [String: String] = ["limit":"10"]
        
        callGetHeaderApi(fileName: getCommentUrl, parameters: parameters) { [self] responseObject, errorResponse in
            if(errorResponse == nil)
            {
                if let json = responseObject as? NSDictionary
                {
                    print(json)
                    
                    if let aryGetData = json.value(forKey: "data") as? NSArray
                    {
                        if aryGetData.count != 0
                        {
                            for result in aryGetData{
                                let obj = ModelComment(dict: result as! NSDictionary)
                                self.aryData.append(obj)
                            }
                            tblComments.reloadData()
                        }
                    }
                }
                else
                {
                    CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
                }
            }
            else
            {
                CRNotifications.showNotification(type: CRNotifications.error, title: "noResponse".localized, message: "noResponseMessage".localized, dismissDelay: 3)
            }
            SKActivityIndicator.dismiss()
        }
    }
    
    // MARK: UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommentsCell") as! CommentsCell
        cell.selectionStyle = .none
        
        cell.lblUserNo.text = aryData[indexPath.row].date
        
        let dicData = aryData[indexPath.row].owner
        
        cell.lblUserName.text = (dicData.value(forKey: "title") as! String) + " " + (dicData.value(forKey: "firstName") as! String) + " " + (dicData.value(forKey: "lastName") as! String)
        cell.lblComment.text = aryData[indexPath.row].comment
        
        if let strProfilePic = dicData.value(forKey: "picture") as? String
        {
            cell.imgUser.sd_setImage(with: URL.init(string: strProfilePic), placeholderImage: UIImage.init(named: ""), options: .refreshCached, progress: nil, completed: nil)
        }
        
        return cell
    }
    
    // MARK: IBAction
    @IBAction func btnBack(_ sender: AnyObject)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
}
